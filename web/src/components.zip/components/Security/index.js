const Security = require('./Security');

module.exports = Security;
