const SecurityContainer = require('./SecurityContainer');

module.exports = SecurityContainer;
