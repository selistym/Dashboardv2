const SecuritySearch = require('./SecuritySearch');

module.exports = SecuritySearch;
