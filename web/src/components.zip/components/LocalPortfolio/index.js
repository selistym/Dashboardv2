const LocalPortfolio = require('./LocalPortfolio');

module.exports = LocalPortfolio;
