const PortfolioContainer = require('./PortfolioContainer');

module.exports = PortfolioContainer;
