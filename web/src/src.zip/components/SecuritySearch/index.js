const SecuritySearchLayout = require('./SecuritySearchLayout');

module.exports = SecuritySearchLayout;
