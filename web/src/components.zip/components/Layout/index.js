import Layout from './Layout.js';

export default Layout;
